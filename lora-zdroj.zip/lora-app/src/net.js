// Spojenie s Firebase pre hru cez internet. Zostavené do www/net.js príkazom: npm run build:net
import { initializeApp } from 'firebase/app';
import { initializeAuth, indexedDBLocalPersistence, browserLocalPersistence, signInAnonymously, onAuthStateChanged } from 'firebase/auth';
import { getDatabase, ref, onValue, set, update, runTransaction, onDisconnect } from 'firebase/database';

const cfg = window.FIREBASE_CONFIG;
if (cfg && cfg.apiKey && cfg.databaseURL) {
  const app = initializeApp(cfg);
  const auth = initializeAuth(app, { persistence: [indexedDBLocalPersistence, browserLocalPersistence] });
  const db = getDatabase(app);
  let uidPromise = null;
  const ready = () => {
    if (!uidPromise) {
      uidPromise = new Promise((resolve, reject) => {
        const stop = onAuthStateChanged(auth, (u) => {
          if (u) { stop(); resolve(u.uid); }
          else signInAnonymously(auth).catch((e) => { stop(); uidPromise = null; reject(e); });
        });
      });
    }
    return uidPromise;
  };
  window.LoraNet = {
    ready,
    watch(path, cb) { return onValue(ref(db, path), (s) => cb(s.val()), (e) => cb(undefined, e)); },
    set: (path, val) => set(ref(db, path), val),
    update: (path, obj) => update(ref(db, path), obj),
    async claim(path, uid) {
      try { const r = await runTransaction(ref(db, path), (cur) => (cur === null ? uid : undefined)); return r.committed && r.snapshot.val() === uid; }
      catch (e) { return false; }
    },
    presence(path) {
      const r = ref(db, path);
      const stop = onValue(ref(db, '.info/connected'), (s) => {
        if (s.val() === true) onDisconnect(r).remove().then(() => set(r, true)).catch(() => {});
      });
      return () => { stop(); set(r, null).catch(() => {}); };
    },
    connected(cb) { return onValue(ref(db, '.info/connected'), (s) => cb(!!s.val())); },
  };
}
