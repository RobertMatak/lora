package sk.lora.protokol;

import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {}
