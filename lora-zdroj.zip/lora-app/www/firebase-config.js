// Nastavenia Firebase pre hru cez internet (z Firebase konzoly → Project settings → Your apps).
window.FIREBASE_CONFIG = {
  apiKey: "AIzaSyAuvm7b2gv7GKJG4TwB3MIAmrbNAqfRuHs",
  authDomain: "lora-cb8be.firebaseapp.com",
  databaseURL: "https://lora-cb8be-default-rtdb.europe-west1.firebasedatabase.app",
  projectId: "lora-cb8be",
  storageBucket: "lora-cb8be.firebasestorage.app",
  messagingSenderId: "1014249495896",
  appId: "1:1014249495896:web:140e52e89a8dbc3963d92d"
};
