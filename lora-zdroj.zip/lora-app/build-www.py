# Zostaví www/index.html z hlavného súboru appky (lora.html)
import re, sys
src = open(sys.argv[1]).read()
src = re.sub(r'<link rel="preconnect"[^>]*>\n', '', src)
src = re.sub(r'<link rel="stylesheet" href="https://fonts.googleapis.com[^>]*>',
  '<link rel="stylesheet" href="fonts.css">\n<link rel="manifest" href="manifest.webmanifest">\n<link rel="apple-touch-icon" href="icon-512.png">\n<script src="firebase-config.js"></script>\n<script src="net.js"></script>', src)
head, rest = src.split('</style>', 1)
html = '<!doctype html>\n<html lang="sk">\n<head>\n<meta charset="utf-8">\n<meta name="viewport" content="width=device-width,initial-scale=1,viewport-fit=cover,user-scalable=no">\n' + head + '</style>\n</head>\n<body>\n' + rest + '\n</body>\n</html>\n'
html = html.replace('*{box-sizing:border-box}', '*{box-sizing:border-box}\n:root{padding-top:env(safe-area-inset-top,0px);padding-bottom:env(safe-area-inset-bottom,0px)}\nbody{margin:0}\n[hidden]{display:none!important}', 1)
open('www/index.html', 'w').write(html)
print('www/index.html ok')
