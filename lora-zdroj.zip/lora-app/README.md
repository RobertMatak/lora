# Lóra – protokol o hre (Android / iOS)

Počítadlo trestných bodov pre kartovú hru Lóra podľa našich domácich pravidiel. Funguje úplne offline, protokol sa ukladá v telefóne.

Appka je postavená na [Capacitor](https://capacitorjs.com): celé rozhranie je v `www/index.html`, priečinky `android/` a `ios/` sú hotové natívne projekty (ikony a úvodná obrazovka sú už vygenerované).

## Čo appka vie

Hrá sa podľa domácich pravidiel:

- 2 až 6 hráčov
- Srdcia, Zeleň, Žaluď, Guľa: 1 bod za kartu; kto zoberie všetkých 8, má 0 a ostatní po 8
- Dolníky, Horníky, Králi: 2 body za kus, vyložený 4 body
- Esá: 3 body za kus, vyložené 6 bodov
- Maturita: každý hráč raz maturuje, 1 bod za každé státie (počítadlo počas hry) a 1 bod za každú kartu, ktorá zostala v ruke
- Náhodná maturita na otočenú kartu, koľkokrát chcete
- ďalšie kolá so sčítaním bodov
- protokol s bodmi za hru alebo priebežným súčtom, oprava aj zmazanie zápisu, vrátenie posledného zápisu

## Android

Potrebuješ [Android Studio](https://developer.android.com/studio) a Node.js 20+.

```bash
npm install
npx cap sync android
npx cap open android
```

V Android Studiu:
- **Spustiť na telefóne:** pripoj telefón cez USB (zapnuté ladenie USB) a stlač ▶ Run.
- **APK súbor:** Build → Build App Bundle(s) / APK(s) → Build APK(s). APK nájdeš v `android/app/build/outputs/apk/debug/`, môžeš ho poslať do telefónu a nainštalovať.
- **Google Play:** Build → Generate Signed App Bundle.

## iOS

Potrebuješ Mac s [Xcode](https://developer.apple.com/xcode/) 16+.

```bash
npm install
npx cap sync ios
npx cap open ios
```

V Xcode vyber v *Signing & Capabilities* svoj tím (stačí bezplatné Apple ID), pripoj iPhone a stlač ▶ Run. Na App Store treba platený Apple Developer účet (Product → Archive).

## Úpravy

Zmeny rob v `www/index.html`, potom spusti `npx cap sync`. Na rýchle skúšanie stačí otvoriť `www/index.html` v prehliadači.


